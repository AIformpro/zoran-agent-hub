from zahub.core import ZoranAgentHub

def test_add_agent():
    hub = ZoranAgentHub()
    result = hub.add_agent("agent1", "leader")
    assert "agent1" in hub.agents and "leader" in result
