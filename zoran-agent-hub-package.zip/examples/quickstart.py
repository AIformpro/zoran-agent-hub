from zahub.core import ZoranAgentHub

hub = ZoranAgentHub()
print(hub.add_agent("agent1", "leader"))
print(hub.consensus())
