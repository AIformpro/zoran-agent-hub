class ZoranAgentHub:
    def __init__(self):
        self.agents = {}
    def add_agent(self, name, role):
        self.agents[name] = role
        return f"Agent {name} ajouté avec le rôle {role}"
    def consensus(self):
        return "Consensus simulé atteint"
